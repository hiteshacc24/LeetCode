package com.company;

import sun.jvm.hotspot.debugger.windbg.DLL;

import java.util.Dictionary;
import java.util.Hashtable;

public class LRUCache {
    class DLinkedNode {
        int key;
        int val;
        DLinkedNode prev;
        DLinkedNode next;
    }
    private void addNode(DLinkedNode node) {
        node.next = tail;
        node.prev = head;

        head.next.prev = node;
        head.next = node;
    }
    private void removeNode(DLinkedNode node) {
        DLinkedNode prev = node.prev;
        DLinkedNode next = node.next;
        prev.next = next;
        next.prev = prev;
    }
    private void moveToHead(DLinkedNode node) {
        removeNode(node);
        addNode(node);
    }
    private DLinkedNode popTail() {
        DLinkedNode res = tail.prev;
        removeNode(res);
        return  res;
    }
    private int size;
    private int capacity;
    private DLinkedNode head;
    private DLinkedNode tail;
    private Hashtable<Integer, DLinkedNode> cache = new Hashtable<>();
    private LRUCache(int capacity) {
        this.size = 0;
        this.capacity = capacity;
        head = new DLinkedNode();
        tail = new DLinkedNode();
        head.next = tail;
        tail.prev = head;
    }
    public int get(int key) {
        DLinkedNode node = cache.get(key);
        if(node == null) return -1;
        moveToHead(node);
        return node.val;
    }
    public void put(int key, int value) {
        DLinkedNode node = cache.get(key);
        if(node == null) {
            DLinkedNode newNode = new DLinkedNode();
            newNode.key = key;
            newNode.val = value;
            addNode(newNode);
            cache.put(key, newNode);
            size++;
            //eviction policy
            if(size > capacity) {
                DLinkedNode tail = popTail();
                cache.remove(tail.key);
                size--;
            }
        }
        //update the current value of node
        else {
            node.val = value;
            moveToHead(node);
        }
    }
    public static void main(String[] args) {
        LRUCache c = new LRUCache(2);
        c.put(1, 1);
        c.put(2,2);
        c.put(3,3);
        int a = c.get(2);
    }
}
